
<?php
require 'users/connect.php';
session_start();

if(!isset($_SESSION['username']))
{
    header('location: login.php');
}

if(isset($_POST['submit']))
{
    $full_name = $_POST['fullName'];
    $email = $_POST['email'];
    $contact_number = $_POST['phone'];
    $location = $_POST['location'];
    $work_experience = $_POST['experience'];
    $education = $_POST['education'];
    $skills = $_POST['skills'];
    $portfolio_url = $_POST['portfolio'];
    $linkedin_url = $_POST['linkedin'];
    $desired_job_position = $_POST['desiredPosition'];
    $salary_expectations = !empty($_POST['salary']) ? $_POST['salary'] : NULL; // Salary is optional


    $qry = "INSERT INTO JobSeekerInformation (id ,full_name, email, contact_number, location, work_experience, education, skills, portfolio_url, linkedin_url, desired_job_position, salary_expectations)
            VALUES (null,'$full_name','$email' ,'$contact_number','$location','$work_experience','$education','$skills','$portfolio_url','$linkedin_url','$desired_job_position ','$salary_expectations')";


    if(!$conn->query($qry))
    {
        die('Error: '. $conn->error);
    }

    echo '<script>alert("Your details submitted successfully!")</script>';
    echo '<script>window.location.href="index.php"</script>';
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Seeker Information Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 800px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            color: #333;
        }

        input[type="text"],
        input[type="email"],
        input[type="tel"],
        input[type="url"],
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
            resize: vertical;
        }

        button[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            border: none;
            border-radius: 4px;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button[type="submit"]:hover {
            background-color: #0056b3;
        }

        @media (max-width: 600px) {
            .container {
                padding: 15px;
            }

            h2 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Job Seeker Information Form</h2>
        <form action="#" method="post">

            <div class="form-group">
                <label for="fullName">Full Name:</label>
                <input type="text" id="fullName" name="fullName" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="phone">Contact Number:</label>
                <input type="tel" id="phone" name="phone" required>
            </div>
            <div class="form-group">
                <label for="location">Location:</label>
                <input type="text" id="location" name="location" required>
            </div>

            <div class="form-group">
                <label for="experience">Work Experience (Job Title, Company, Dates, Responsibilities):</label>
                <textarea id="experience" name="experience" rows="6" required></textarea>
            </div>


            <div class="form-group">
                <label for="education">Education (Degree, Institution, Graduation Date):</label>
                <textarea id="education" name="education" rows="4" required></textarea>
            </div>

            <div class="form-group">
                <label for="skills">Skills (Technical & Soft Skills):</label>
                <textarea id="skills" name="skills" rows="4" required></textarea>
            </div>

            <div class="form-group">
                <label for="portfolio">Portfolio/Work Samples (URL):</label>
                <input type="url" id="portfolio" name="portfolio">
            </div>

            <div class="form-group">
                <label for="linkedin">LinkedIn Profile (URL):</label>
                <input type="url" id="linkedin" name="linkedin">
            </div>

            <div class="form-group">
                <label for="desiredPosition">Desired Job Position:</label>
                <input type="text" id="desiredPosition" name="desiredPosition" required>
            </div>

            <div class="form-group">
                <label for="salary">Salary Expectations (Optional):</label>
                <input type="text" id="salary" name="salary">
            </div>

            <div class="form-group">
                <button type="submit" name="submit">Submit</button>
            </div>
        </form>
    </div>
</body>
</html>